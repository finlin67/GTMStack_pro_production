import { NextResponse } from 'next/server'
import fs from 'node:fs'
import path from 'node:path'
import { verifyAdminToken, ADMIN_COOKIE_NAME } from '@/lib/admin-auth'
import { cookies } from 'next/headers'

function parseCsvRow(line: string): string[] {
  const out: string[] = []
  let cur = ''
  let inQuotes = false
  for (let i = 0; i < line.length; i++) {
    const c = line[i]
    if (c === '"') inQuotes = !inQuotes
    else if (inQuotes) cur += c
    else if (c === ',') {
      out.push(cur.trim())
      cur = ''
    } else cur += c
  }
  out.push(cur.trim())
  return out
}

export async function GET() {
  const cookieStore = await cookies()
  const token = cookieStore.get(ADMIN_COOKIE_NAME)?.value
  if (!token || !verifyAdminToken(token)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const csvPath = path.join(process.cwd(), 'src', 'data', 'page-registry.csv')
  if (!fs.existsSync(csvPath)) {
    return NextResponse.json({ rows: [], header: [] })
  }
  const raw = fs.readFileSync(csvPath, 'utf-8')
  const lines = raw.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
  if (lines.length < 2) {
    return NextResponse.json({ rows: [], header: parseCsvRow(lines[0] || '') })
  }
  const header = parseCsvRow(lines[0])
  const rows = lines.slice(1).map((line) => {
    const values = parseCsvRow(line)
    const row: Record<string, string> = {}
    header.forEach((h, i) => { row[h] = values[i] ?? '' })
    return row
  })
  return NextResponse.json({ header, rows })
}
