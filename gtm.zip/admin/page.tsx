'use client'

import React, { useState, useEffect, useCallback } from 'react'
import AdminGate from '@/components/admin/AdminGate'
import AdminLayout, { type AdminSectionId } from '@/components/admin/AdminLayout'
import PageList, { type PageRow } from '@/components/admin/PageList'
import PageForm from '@/components/admin/PageForm'
import BlogForm from '@/components/admin/BlogForm'
import TemplatesPanel, { type TemplateEntry } from '@/components/admin/TemplatesPanel'
import UpdateTemplateWizard from '@/components/admin/wizards/UpdateTemplateWizard'
import AddTemplateWizard from '@/components/admin/wizards/AddTemplateWizard'
import UpdateContentWizard from '@/components/admin/wizards/UpdateContentWizard'
import EditPageWizard from '@/components/admin/wizards/EditPageWizard'
import QuickPageUpdateWizard from '@/components/admin/wizards/QuickPageUpdateWizard'
import { CheckCircle, XCircle, AlertCircle, RefreshCw, PlusCircle, FileText, Zap } from 'lucide-react'

export default function AdminPage() {
  const [section, setSection] = useState<AdminSectionId>('expertise')
  const [pages, setPages] = useState<PageRow[]>([])
  const [pagesLoading, setPagesLoading] = useState(true)
  const [templates, setTemplates] = useState<TemplateEntry[]>([])
  const [slugs, setSlugs] = useState<{ industries: string[]; expertise: string[]; caseStudies: string[] }>({
    industries: [],
    expertise: [],
    caseStudies: [],
  })
  const [formMode, setFormMode] = useState<'list' | 'add' | 'edit'>('list')
  const [editingRow, setEditingRow] = useState<PageRow | null>(null)
  const [editingPage, setEditingPage] = useState<PageRow | null>(null)
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null)
  const [auditLog, setAuditLog] = useState<string | null>(null)
  const [auditRunning, setAuditRunning] = useState(false)
  const [auditStatus, setAuditStatus] = useState<'Passed' | 'Failed' | 'Unknown'>('Unknown')
  const [wizard, setWizard] = useState<'quick' | 'update-template' | 'add-template' | 'update-content' | null>(null)

  const loadPages = useCallback(async () => {
    setPagesLoading(true)
    try {
      const res = await fetch('/api/admin/pages')
      if (res.ok) {
        const data = await res.json()
        setPages(data.rows || [])
      }
    } catch {
      setMessage({ type: 'error', text: 'Failed to load pages' })
    } finally {
      setPagesLoading(false)
    }
  }, [])

  const loadSlugs = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/slugs')
      if (res.ok) {
        const data = await res.json()
        setSlugs({
          industries: data.industries || [],
          expertise: data.expertise || [],
          caseStudies: data.caseStudies || [],
        })
      }
    } catch {
      // non-blocking
    }
  }, [])

  const loadTemplates = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/templates')
      if (res.ok) {
        const data = await res.json()
        setTemplates(data.templates || [])
      }
    } catch {
      // non-blocking
    }
  }, [])

  useEffect(() => {
    if (section !== 'blog' && section !== 'templates') loadPages()
  }, [section, loadPages])

  useEffect(() => {
    if (section !== 'blog' && section !== 'templates' && formMode === 'list') loadSlugs()
  }, [section, formMode, loadSlugs])

  useEffect(() => {
    if (section !== 'blog' && (section === 'templates' || formMode === 'list' || wizard !== null)) {
      void loadTemplates()
    }
  }, [section, formMode, wizard, loadTemplates])

  const handlePageSuccess = (log: string) => {
    setMessage({ type: 'success', text: 'Page installed. ' + (log.slice(0, 200) + (log.length > 200 ? '…' : '')) })
    setFormMode('list')
    setEditingRow(null)
    setEditingPage(null)
    loadPages()
    loadTemplates()
  }

  const handleBlogSuccess = (slug: string) => {
    setMessage({ type: 'success', text: `Post created: /blog/${slug}` })
    setSection('blog')
  }

  const handlePreview = (route: string) => {
    if (route && route !== '#') {
      const base = typeof window !== 'undefined' ? window.location.origin : ''
      window.open(base + route, '_blank', 'noopener')
    }
  }

  const runAudit = async () => {
    setAuditRunning(true)
    setAuditLog(null)
    setMessage(null)
    setAuditStatus('Unknown')
    try {
      const res = await fetch('/api/admin/registry-audit', { method: 'POST' })
      const data = await res.json().catch(() => ({}))
      setAuditLog(data.log || data.error || 'No output')
      if (data.ok) {
        setAuditStatus('Passed')
        setMessage({ type: 'success', text: 'Audit passed.' })
      } else {
        setAuditStatus('Failed')
        setMessage({ type: 'error', text: 'Audit failed. See log below.' })
      }
    } catch (err) {
      setAuditStatus('Failed')
      setMessage({ type: 'error', text: err instanceof Error ? err.message : 'Audit request failed' })
    } finally {
      setAuditRunning(false)
    }
  }

  const renderMain = () => {
    if (section === 'templates') {
      return (
        <TemplatesPanel
          onTemplatesUpdated={(t) => {
            setTemplates(t)
          }}
        />
      )
    }

    if (section === 'blog') {
      return (
        <div className="space-y-6">
          <h2 className="text-lg font-bold text-white">Blog (MDX)</h2>
          <p className="text-slate-400 text-sm">
            Create a new post. It will be saved to <code className="text-slate-300">content/blog/posts/[slug].mdx</code> and available at <code className="text-slate-300">/blog/[slug]</code>.
          </p>
          <BlogForm onSuccess={handleBlogSuccess} />
        </div>
      )
    }

    if (formMode === 'add') {
      return (
        <PageForm
          initial={null}
          slugs={slugs}
          templates={templates}
          onSuccess={handlePageSuccess}
          onCancel={() => { setFormMode('list'); setEditingRow(null) }}
        />
      )
    }

    return (
      <div className="space-y-6">
        <button
          type="button"
          onClick={() => setWizard('quick')}
          className="w-full max-w-xl flex items-start gap-4 p-5 rounded-2xl border-2 border-[#36C0CF]/30 bg-[#36C0CF]/5 hover:bg-[#36C0CF]/10 hover:border-[#36C0CF]/50 transition-all text-left group"
        >
          <div className="shrink-0 w-12 h-12 rounded-xl bg-[#36C0CF]/20 flex items-center justify-center group-hover:bg-[#36C0CF]/30 transition-colors">
            <Zap className="text-[#36C0CF]" size={24} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Quick Page Update</h3>
            <p className="text-slate-400 text-sm mt-0.5">
              Enter the page URL → choose what to change → done
            </p>
          </div>
        </button>
        <PageList
          rows={pages}
          templates={templates}
          sectionFilter={section}
          auditStatus={auditStatus}
          onEdit={(row) => { setEditingPage(row) }}
          onAdd={() => { setEditingRow(null); setFormMode('add') }}
          onPreview={handlePreview}
          onEditTemplate={(row) => { setEditingPage(row) }}
          onEditContent={(row) => { setEditingPage(row) }}
        />
        <div className="flex flex-wrap gap-3 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={() => setWizard('update-template')}
            className="px-4 py-2 rounded-lg border border-slate-600 text-slate-300 hover:bg-white/5 flex items-center gap-2"
          >
            <RefreshCw size={18} />
            Update existing template
          </button>
          <button
            type="button"
            onClick={() => setWizard('add-template')}
            className="px-4 py-2 rounded-lg border border-slate-600 text-slate-300 hover:bg-white/5 flex items-center gap-2"
          >
            <PlusCircle size={18} />
            Add new template
          </button>
          <button
            type="button"
            onClick={() => setWizard('update-content')}
            className="px-4 py-2 rounded-lg border border-slate-600 text-slate-300 hover:bg-white/5 flex items-center gap-2"
          >
            <FileText size={18} />
            Update content (quick)
          </button>
        </div>
        <div className="pt-4 border-t border-slate-800">
          <button
            type="button"
            onClick={runAudit}
            disabled={auditRunning}
            className="px-4 py-2 rounded-lg border border-slate-600 text-slate-300 hover:bg-white/5 disabled:opacity-50 flex items-center gap-2 transition-colors"
          >
            {auditRunning ? 'Running…' : 'Run registry:audit'}
          </button>
          {auditLog !== null && (
            <pre className="mt-4 p-4 rounded-lg bg-[#0A0F2D] border border-slate-700 text-xs text-slate-300 overflow-auto max-h-64 whitespace-pre-wrap">
              {auditLog}
            </pre>
          )}
        </div>
      </div>
    )
  }

  return (
    <AdminGate>
      <AdminLayout section={section} onSectionChange={setSection}>
        {message && (
          <div
            className={`mb-6 flex items-center gap-2 px-4 py-3 rounded-lg ${
              message.type === 'success'
                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                : message.type === 'error'
                ? 'bg-red-500/10 text-red-300 border border-red-500/20'
                : 'bg-slate-500/10 text-slate-300 border border-slate-600'
            }`}
          >
            {message.type === 'success' && <CheckCircle size={20} />}
            {message.type === 'error' && <XCircle size={20} />}
            {message.type === 'info' && <AlertCircle size={20} />}
            <span>{message.text}</span>
            <button
              type="button"
              onClick={() => setMessage(null)}
              className="ml-auto text-slate-400 hover:text-white"
              aria-label="Dismiss"
            >
              ×
            </button>
          </div>
        )}
        {pagesLoading && section !== 'blog' && section !== 'templates' && formMode === 'list' ? (
          <div className="flex items-center gap-2 text-slate-400">
            <div className="w-5 h-5 border-2 border-[#36C0CF]/40 border-t-[#36C0CF] rounded-full animate-spin" />
            Loading pages…
          </div>
        ) : (
          renderMain()
        )}
      </AdminLayout>

      {wizard === 'quick' && (
        <QuickPageUpdateWizard
          templates={templates}
          pages={pages}
          slugs={slugs}
          onClose={() => setWizard(null)}
          onSuccess={(text) => {
            setMessage({ type: text.startsWith('Error') || text.startsWith('Failed') || text.startsWith('Write failed') ? 'error' : 'success', text })
            loadPages()
            loadTemplates()
          }}
          onTemplatesUpdated={setTemplates}
        />
      )}
      {wizard === 'update-template' && (
        <UpdateTemplateWizard
          templates={templates}
          pages={pages}
          onClose={() => setWizard(null)}
          onSuccess={(text) => { setMessage({ type: text.startsWith('Error') || text.startsWith('Failed') ? 'error' : 'success', text }); loadPages(); loadTemplates() }}
        />
      )}
      {wizard === 'add-template' && (
        <AddTemplateWizard
          templates={templates}
          pages={pages}
          slugs={slugs}
          onClose={() => setWizard(null)}
          onSuccess={(text) => { setMessage({ type: 'success', text }); loadPages(); loadTemplates() }}
          onTemplatesUpdated={setTemplates}
        />
      )}
      {wizard === 'update-content' && (
        <UpdateContentWizard
          templates={templates}
          pages={pages}
          onClose={() => setWizard(null)}
          onSuccess={(text) => { setMessage({ type: text.startsWith('Failed') ? 'error' : 'success', text }); loadPages() }}
        />
      )}

      {editingPage && (
        <EditPageWizard
          page={editingPage}
          templates={templates}
          onClose={() => { setEditingPage(null) }}
          onSuccess={(text) => {
            setMessage({ type: text.includes('failed') || text.includes('not in the registry') ? 'error' : 'success', text })
            setEditingPage(null)
            loadPages()
            loadTemplates()
          }}
          onUploadNewTemplate={() => { setEditingPage(null); setWizard('add-template') }}
        />
      )}
    </AdminGate>
  )
}
